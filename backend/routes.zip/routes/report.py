from fastapi import APIRouter, Depends
from models.db import get_db
from fastapi.security import HTTPBearer
from datetime import datetime

router = APIRouter()
security = HTTPBearer()

@router.post("/generate_report")
def generate_report(data: dict, token: str = Depends(security)):  # data: {"anamnese": "...", "diagnosis": "...", "image": "..."}
    user_id = 1  # From token
    content = f"Date: {datetime.now()}\nAnamnèse: {data['anamnese']}\nDiagnostic IA: {data['diagnosis']}\nImage: {data.get('image', 'N/A')}"
    with get_db() as conn:
        conn.execute("INSERT INTO reports (user_id, content, diagnosis, date) VALUES (?, ?, ?, ?)",
                     (user_id, content, data['diagnosis'], datetime.now().isoformat()))
        conn.commit()
    return {"report_id": conn.lastrowid, "content": content}
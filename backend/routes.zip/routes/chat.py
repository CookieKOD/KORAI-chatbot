# backend/routes/chat.py   (ou directement dans main.py)

from fastapi import APIRouter, Request
from pydantic import BaseModel
from utils.rag_context import get_rag_context
from utils.mistral_client import mistral_client 
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
import sys
import os
sys.path.append("/home/korai-app/backend")  # ajuste si besoin

router = APIRouter()

class ChatRequest(BaseModel):
    message: str

@router.post("/chat")
async def chat(request: ChatRequest):
    try:
        # ON APPELLE DIRECTEMENT TON RAG EXISTANT
        response = rag_chain.invoke({"input": request.message})
        answer = response.get("answer", response) if isinstance(response, dict) else str(response)      
        return {"response": answer.strip()}
    
    except Exception as e:
        print("Erreur RAG:", e)
        return {"response": "Désolé, je suis temporairement indisponible."}
from fastapi import APIRouter, UploadFile, File
from PIL import Image
import torch
import torchvision.transforms as transforms
from io import BytesIO
import base64
from utils.rag_context import add_rag_context 
from datetime import datetime

router = APIRouter()

# Charger modèle ResNet18 (placeholder, fine-tune pour ORL)
model = torch.hub.load('pytorch/vision:v0.10.0', 'resnet18', pretrained=True)
model.eval()

transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

@router.post("/analyze_image")
async def analyze_image(file: UploadFile = File(...)):
    contents = await file.read()
    image = Image.open(BytesIO(contents)).convert('RGB')
    input_tensor = transform(image).unsqueeze(0)

    with torch.no_grad():
        output = model(input_tensor)
        probs = torch.nn.functional.softmax(output[0], dim=0)
        confidence = probs.max().item() * 100
        diagnosis = "Otite Moyenne Aiguë"  # Placeholder
        findings = ["Tympan bombé", "Rougeur intense"]  # Placeholder

    # Préparer le texte pour le RAG
    context_text = f"""
    NOUVEAU RÉSULTAT OTOSCOPIQUE ({datetime.now().strftime('%d/%m/%Y %H:%M')}):
    - Diagnostic : {diagnosis}
    - Fiabilité : {confidence:.0f}%
    - Signes cliniques : {', '.join(findings)}
    """

    # Injection dans le RAG
    add_rag_context(user_id=1, text=context_text)  # user_id=1 pour test

    return {
        "diagnosis": diagnosis,
        "signs": findings,
        "confidence": f"{confidence:.0f}%",
        "image_base64": base64.b64encode(contents).decode()
    }

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer
from passlib.context import CryptContext
from jose import JWTError, jwt
from datetime import datetime, timedelta
from pydantic import BaseModel
from models.db import get_db
import os
from dotenv import load_dotenv

load_dotenv()
SECRET_KEY = "votre_secret_key"  # Changez en prod
ALGORITHM = "HS256"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

router = APIRouter()
security = HTTPBearer()

class User(BaseModel):
    username: str
    password: str

def verify_password(plain, hashed): return pwd_context.verify(plain, hashed)
def get_password_hash(password): return pwd_context.hash(password)
def create_access_token(data: dict): 
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=30)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

@router.post("/signup")
def signup(user: User):
    with get_db() as conn:
        hashed = get_password_hash(user.password)
        try:
            conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (user.username, hashed))
            conn.commit()
            return {"msg": "User created"}
        except:
            raise HTTPException(400, "Username exists")

@router.post("/login")
def login(user: User):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM users WHERE username=?", (user.username,)).fetchone()
        if not row or not verify_password(user.password, row['password']):
            raise HTTPException(401, "Invalid credentials")
        token = create_access_token({"sub": user.username})
        return {"access_token": token}